import os

# Nhập đường dẫn gốc
path = input("Nhập đường dẫn tới thư mục: ").strip()

# Nhập khoảng số cho thư mục "tan gai"
start = int(input("Từ số: "))
end   = int(input("Đến số: "))

# Tạo thư mục gốc nếu chưa có
os.makedirs(path, exist_ok=True)

# Tạo các thư mục "tan gai 1", "tan gai 2", ...
for i in range(start, end + 1):
    folder_name = f"tan gai {i}"
    folder_path = os.path.join(path, folder_name)
    os.makedirs(folder_path, exist_ok=True)

    # Trong mỗi "tan gai i" tạo 5 thư mục con: 1, 2, 3, 4, 5
    for j in range(1, 6):
        sub_path = os.path.join(folder_path, str(j))
        os.makedirs(sub_path, exist_ok=True)

        # Mỗi thư mục con chứa 1 file .txt (tên trống)
        file_path = os.path.join(sub_path, ".txt")
        open(file_path, "w").close()

print(f"Đã tạo {end - start + 1} thư mục, mỗi thư mục có 5 thư mục con, mỗi thư mục con có 1 file .txt")